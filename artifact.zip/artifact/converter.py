import re
import sys
with open(sys.argv[1]+'.cnf') as f:
    first_line = f.readline()
temp = re.findall(r'\d+', first_line) 
res = list(map(int, temp))
temper=""
for i in res:
    temper=temper+str(i)+","
f = open(sys.argv[1]+'.var', "w")
f.write(temper[:-3])
f.close()
