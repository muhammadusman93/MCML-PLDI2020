import sys
import os
propertyoption = str(sys.argv[1])
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+propertyoption)
