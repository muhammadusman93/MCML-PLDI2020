# REQUIRED IMPORTS
import re
import time
import sys
import pydotplus
import numpy as np
from sklearn import svm
from sklearn import tree
import pickle
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.datasets import make_blobs
from sklearn.metrics import recall_score
from sklearn.externals.six import StringIO  
from sklearn.metrics import precision_score
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score,roc_auc_score)
from sklearn.model_selection import (train_test_split,GridSearchCV)
from sklearn.ensemble import (RandomForestClassifier,GradientBoostingClassifier,AdaBoostClassifier)
#########################################################################################################################
class tree_model:
    def __init__(self,subjectname, X_train,y_train,X_test,y_test,subjectnameb, Xb_train,yb_train,Xb_test,yb_test):
        # GLOBAL VARIABLES
        self.subjectname=subjectname
        self.X_train=X_train
        self.X_test=X_test
        self.y_train=y_train
        self.y_test=y_test
        self.subjectnameb=subjectnameb
        self.Xb_train=Xb_train
        self.Xb_test=Xb_test
        self.yb_train=yb_train
        self.yb_test=yb_test
        self.feature_names=[]
        self.poscon=[]
        self.neucon=[]
        self.negcon=[]
        self.totcon=[]
    #########################################################################################################################
    def traversal(self,model, cand_vects):
     left      = model.tree_.children_left
     right     = model.tree_.children_right
     certainity = model.tree_.threshold
     features  = [cand_vects[i] for i in model.tree_.feature]
     value = model.tree_.value
     listnum = np.argwhere(left == -1)[:,0]     

     def recurse(left, right, descendant,value ,tempvar=None):          
          if tempvar is None:
               tempvar = [descendant]
          if descendant in left:
               root = np.where(left == descendant)[0].item()
               partition = 'l'
          else:
               root = np.where(right == descendant)[0].item()
               partition = 'r'
          if(value[descendant][0][0]==0.0):
              temp='negative'
          elif(value[descendant][0][1]==0.0):
              temp='positive'
          else:
              temp='neutral'   
          if(partition=='r'):
              tempvar.append((features[root], '>', certainity[root],temp ))
          else:
              tempvar.append( (features[root],'<=', certainity[root],temp) )
          if root == 0:
               tempvar.reverse()
               return tempvar
          else:
               return recurse(left, right, root,value ,tempvar)
     for descendant in listnum:
          totcon=[]
          temper=""
          for node in recurse(left, right, descendant,value):
              if(type(node)==tuple):
                 #  print (node)
                   totcon.append(node)
          for i in totcon:
              temper=temper+" "+str(i[0])+str(i[1])+str(i[2])
          if((totcon[len(totcon)-1][3])=='positive'):
              self.poscon.append(temper)
          elif((totcon[len(totcon)-1][3])=='negative'):
              self.negcon.append(temper)
          if((totcon[len(totcon)-1][3])=='neutral'):
              self.neucon.append(temper)
    def base_model_load(self,am,filename):
        for i in range(self.X_train.shape[1]):
            self.feature_names.append(str(i+1))
        header="c ind"
        for i in range(self.X_train.shape[1]):
           header=header+" "+str(i+1)
        header=header+" 0\np cnf "+str(self.X_train.shape[1])+" "
        ####################################################################################################
        clf = tree.DecisionTreeClassifier(random_state=0)
        clf.fit(self.X_train,self.y_train) # TRAIN MODEL
        self.poscon=[]
        self.neucon=[]
        self.negcon=[]
        self.totcon=[]
        self.traversal(clf, self.feature_names)
        newnegative=""
        newpositive=""
        for i in self.poscon:
            temp=""
            for j in i.split():
                if(">" in j):# - if it is set as 1 
                    temp=temp+"-"+str(re.findall(r'\d+', j)[0])+" "
                else:
                    temp=temp+str(re.findall(r'\d+', j)[0])+" "
            newpositive=newpositive+temp+"0\n"
        newpositive=newpositive[:-1]
        for i in self.negcon:
            temp=""
            for j in i.split():
                if(">" in j):# - if it is set as 1 
                    temp=temp+"-"+str(re.findall(r'\d+', j)[0])+" "
                else:
                    temp=temp+str(re.findall(r'\d+', j)[0])+" "
            newnegative=newnegative+temp+"0\n"
        newnegative=newnegative[:-1]
        #############################################################################################################
        clf = tree.DecisionTreeClassifier(random_state=42)
        clf.fit(self.Xb_train,self.yb_train) # TRAIN MODEL      
        self.poscon=[]
        self.neucon=[]
        self.negcon=[]
        self.totcon=[]
        self.traversal(clf, self.feature_names)
        newnegative2=""
        newpositive2=""
        for i in self.poscon:
            temp=""
            for j in i.split():
                if(">" in j):# - if it is set as 1 
                    temp=temp+"-"+str(re.findall(r'\d+', j)[0])+" "
                else:
                    temp=temp+str(re.findall(r'\d+', j)[0])+" "
            newpositive2=newpositive2+temp+"0\n"
        
        newpositive2=newpositive2[:-1]
        for i in self.negcon:
            temp=""
            for j in i.split():
                if(">" in j):# - if it is set as 1 
                    temp=temp+"-"+str(re.findall(r'\d+', j)[0])+" "
                else:
                    temp=temp+str(re.findall(r'\d+', j)[0])+" "
            newnegative2=newnegative2+temp+" 0\n"
        
        newnegative2=newnegative2[:-1]
        ##################################################################################################################
        a=int(newpositive.count('\n'))+int(newpositive2.count('\n'))+2
        tt=header+str(a)+"\n"+newpositive+"\n"+newpositive2
        
        a=int(newpositive.count('\n'))+int(newnegative2.count('\n'))+2
        tf=header+str(a)+"\n"+newpositive+"\n"+newnegative2
        
        a=int(newnegative.count('\n'))+int(newpositive2.count('\n'))+2
        ft=header+str(a)+"\n"+newnegative+"\n"+newpositive2
        
        a=int(newnegative.count('\n'))+int(newnegative2.count('\n'))+2
        ff=header+str(a)+"\n"+newnegative+"\n"+newnegative2
        checker=[]
        checkertemp=[]
        filesecond=str(sys.argv[2])
        self.writetofile(filesecond+"tp/"+self.subjectname+"/tp_"+self.subjectname+"_"+self.subjectnameb+".cnf",tt)
        self.writetofile(filesecond+"fn/"+self.subjectname+"/fn_"+self.subjectname+"_"+self.subjectnameb+".cnf",tf)
        self.writetofile(filesecond+"fp/"+self.subjectname+"/fp_"+self.subjectname+"_"+self.subjectnameb+".cnf",ft)
        self.writetofile(filesecond+"tn/"+self.subjectname+"/tn_"+self.subjectname+"_"+self.subjectnameb+".cnf",ff)
    def writetofile(self,name,text):
        f= open(name,"w")
        f.write(text)
    def run_models(self, am,filename):
        print("Good")
        self.base_model_load(am,filename) # CALL BASE_MODEL METHOD
