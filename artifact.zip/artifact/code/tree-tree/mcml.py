# REQUIRED IMPORTS
import os
import re
import sys
import csv
import time
import math
import pydotplus
import subprocess
import numpy as np
from sklearn import svm
from sklearn import tree
from sklearn.svm import SVC
from tree import tree_model
import sklearn.model_selection
import matplotlib.pyplot as plt
from sklearn import preprocessing
np.set_printoptions(suppress=True)
from sklearn.datasets import make_blobs
from sklearn.metrics import recall_score
from sklearn.externals.six import StringIO  
from sklearn.metrics import precision_score
from sklearn.metrics import confusion_matrix
import warnings; warnings.simplefilter('ignore')
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.metrics import (accuracy_score,roc_auc_score)
from sklearn.model_selection import (train_test_split,GridSearchCV)
from sklearn.ensemble import (RandomForestClassifier,GradientBoostingClassifier,AdaBoostClassifier)
data_path=str(sys.argv[1])  # SPECIFY THE PATH WHERE YOUR ALLOY CSV FILES ARE LOCATED
#########################################################################################################################
def parse_file(pather,opt): # PARSE FILE METHOD TO READ DATA
    if opt==0:
        inputfile = csv.reader(open(pather,'r')) # DEFINES THE INPUT FILE
        for row in inputfile: # TRAVERSES ALL ROWS OF DATA
           #print(map(int, row[-1]))   
           original.append(list(map(int, row[0:-1]))) # ORIGINAL STORES DATA FEATURES
           result.append(list(map(int, row[-1]))) # RESULT STORES DATA LABELS
    else:
        inputfile = csv.reader(open(pather,'r')) # DEFINES THE INPUT FILE
        for row in inputfile: # TRAVERSES ALL ROWS OF DATA
           #print(map(int, row[-1]))   
           originalb.append(list(map(int, row[0:-1]))) # ORIGINAL STORES DATA FEATURES
           resultb.append(list(map(int, row[-1]))) # RESULT STORES DATA LABELS

datas=[]    # DATAS ARRAY STORE LIST OF FILES TO WORK ON
datastemp=[]
X_train=[]  # X_TRAIN WILL STORE TRAINING FEAUTRES. 
y_train=[]  # Y_TRAIN WILL STORE TRAINIGN LABELS
X_test=[]   # X_TEST WILL STORE TESTING FEATURES
y_test=[]   # Y_TEST WILL STORE TESTING LABELS
#########################################################################################################################
# THESE ARE FILES WHICH WE ARE WORKING ON.
filethird=str(sys.argv[3])
datas.append(data_path+filethird+".csv")
datastemp.append(filethird)

datas.append(data_path+filethird+".csv")
datastemp.append(filethird)

# THIS RUNS THE MAIN METHOD
ratio=[0.9]
for j in ratio:
    original=[] # RESETS THE FEATURE ARRAY
    result=[] # RESETS THE LABEL ARRAY
    parse_file(datas[0],0) # CALLS PARSE_FILE METHOD
    finaloriginal=np.array(original) # CONVERTING FEATURE VECTOR TO NUMPY ARRAY
    finalresult=np.array(result) # CONVERTING LABEL VECTOR TO NUMPY ARRAY
    X_train, X_test, y_train, y_test = train_test_split(finaloriginal, finalresult, test_size=j, random_state=42) # TRAIN-TEST SPLIT FUNCTION
    originalb=[] # RESETS THE FEATURE ARRAY
    resultb=[] # RESETS THE LABEL ARRAY
    parse_file(datas[1],1) # CALLS PARSE_FILE METHOD
    finaloriginalb=np.array(originalb) # CONVERTING FEATURE VECTOR TO NUMPY ARRAY
    finalresultb=np.array(resultb) # CONVERTING LABEL VECTOR TO NUMPY ARRAY
    Xb_train, Xb_test, yb_train, yb_test = train_test_split(finaloriginalb, finalresultb, test_size=j, random_state=42) # TRAIN-TEST SPLIT FUNCTION
    q=tree_model(datastemp[0], X_train,  y_train,X_test, y_test,datastemp[1], Xb_train,  yb_train,Xb_test, yb_test) # CREATES THE MODEL 
    q.run_models( int(100-j*100),"_Tree_"+str(int(100-j*100))); # CALL THE RUN_MODELS METHOD
    temp=0