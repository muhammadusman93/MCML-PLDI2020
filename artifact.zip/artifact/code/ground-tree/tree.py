# REQUIRED IMPORTS
import re
import time
import pydotplus
import numpy as np
from sklearn import svm
from sklearn import tree
import pickle
import sys
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.datasets import make_blobs
from sklearn.tree import export_graphviz
from sklearn.metrics import recall_score
from sklearn.externals.six import StringIO  
from sklearn.metrics import precision_score
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score,roc_auc_score)
from sklearn.model_selection import (train_test_split,GridSearchCV)
from sklearn.ensemble import (RandomForestClassifier,GradientBoostingClassifier,AdaBoostClassifier)
#########################################################################################################################
class tree_model:
    def __init__(self,subjectname, X_train,y_train,X_test,y_test):
        # GLOBAL VARIABLES
        self.subjectname=subjectname
        self.X_train=X_train
        self.X_test=X_test
        self.y_train=y_train
        self.y_test=y_test
        self.feature_names=[]
        self.poscon=[]
        self.neucon=[]
        self.negcon=[]
        self.totcon=[]
    #########################################################################################################################
    def traversal(self,model, cand_vects):
     left      = model.tree_.children_left
     right     = model.tree_.children_right
     certainity = model.tree_.threshold
     features  = [cand_vects[i] for i in model.tree_.feature]
     value = model.tree_.value
     listnum = np.argwhere(left == -1)[:,0]     

     def recurse(left, right, descendant,value ,tempvar=None):          
          if tempvar is None:
               tempvar = [descendant]
          if descendant in left:
               root = np.where(left == descendant)[0].item()
               partition = 'l'
          else:
               root = np.where(right == descendant)[0].item()
               partition = 'r'
          if(value[descendant][0][0]==0.0):
              temp='negative'
          elif(value[descendant][0][1]==0.0):
              temp='positive'
          else:
              temp='neutral'   
          if(partition=='r'):
              tempvar.append((features[root], '>', certainity[root],temp ))
          else:
              tempvar.append( (features[root],'<=', certainity[root],temp) )
          if root == 0:
               tempvar.reverse()
               return tempvar
          else:
               return recurse(left, right, root,value ,tempvar)
     for descendant in listnum:
          totcon=[]
          temper=""
          for node in recurse(left, right, descendant,value):
              if(type(node)==tuple):
                 #  print (node)
                   totcon.append(node)
          for i in totcon:
              temper=temper+" "+str(i[0])+str(i[1])+str(i[2])
          if((totcon[len(totcon)-1][3])=='positive'):
              self.poscon.append(temper)
          elif((totcon[len(totcon)-1][3])=='negative'):
              self.negcon.append(temper)
          if((totcon[len(totcon)-1][3])=='neutral'):
              self.neucon.append(temper)
    def base_model_load(self,am,filename):
        for i in range(self.X_train.shape[1]):
            self.feature_names.append(str(i+1))
        header="c ind "
        for i in range(self.X_train.shape[1]):
           header=header+" "+str(i+1)
        header=header+" 0"
        ####################################################################################################
        clf = tree.DecisionTreeClassifier(random_state=0)
        clf.fit(self.X_train,self.y_train) # TRAIN MODEL
        self.poscon=[]
        self.neucon=[]
        self.negcon=[]
        self.totcon=[]
        self.traversal(clf, self.feature_names)
        newnegative=""
        newpositive=""
        for i in self.poscon:
            temp=""
            for j in i.split():
                if(">" in j):# - if it is set as 1 
                    temp=temp+"-"+str(re.findall(r'\d+', j)[0])+" "
                else:
                    temp=temp+str(re.findall(r'\d+', j)[0])+" "
            newpositive=newpositive+temp+" 0\n"
        
        newpositive=newpositive[:-1]
        for i in self.negcon:
            temp=""
            for j in i.split():
                if(">" in j):# - if it is set as 1 
                    temp=temp+"-"+str(re.findall(r'\d+', j)[0])+" "
                else:
                    temp=temp+str(re.findall(r'\d+', j)[0])+" "
            newnegative=newnegative+temp+" 0\n"
        
        newnegative=newnegative[:-1]
        filesecond=str(sys.argv[2])
        filethird=str(sys.argv[3])
        with open(filesecond+'true/'+self.subjectname+'.cnf') as file:
            newpositive2 = file.read()
        newpositive2=newpositive2[:-1]
        with open(filesecond+'false/'+self.subjectname+'.cnf') as file:
            newnegative2 = file.read()
        newnegative2=newnegative2[:-1]
        #############################################################################################################
        regex = re.compile('p cnf ([0-9]* [0-9]*)')
        
        a=int(newpositive2.count('\n'))+int(newpositive.count('\n'))
        t=[int(s) for s in regex.findall(newpositive2)[0].split() if s.isdigit()]
        old="p cnf "+str(t[0])+" "+str(t[1])
        new="p cnf "+str(t[0])+" "+str(a)
        newpositive2=newpositive2
        tt=newpositive2.replace(old,new)+"\n"+newpositive     
        
        a=int(newpositive2.count('\n'))+int(newnegative.count('\n'))
        t=[int(s) for s in regex.findall(newpositive2)[0].split() if s.isdigit()]
        old="p cnf "+str(t[0])+" "+str(t[1])
        new="p cnf "+str(t[0])+" "+str(a)
        newpositive2=newpositive2
        tf=newpositive2.replace(old,new)+"\n"+newnegative
        
        a=int(newnegative2.count('\n'))+int(newpositive.count('\n'))
        t=[int(s) for s in regex.findall(newnegative2)[0].split() if s.isdigit()]
        old="p cnf "+str(t[0])+" "+str(t[1])
        new="p cnf "+str(t[0])+" "+str(a)
        newnegative2=newnegative2
        ft=newnegative2.replace(old,new)+"\n"+newpositive    
        
        a=int(newnegative2.count('\n'))+int(newnegative.count('\n'))
        t=[int(s) for s in regex.findall(newnegative2)[0].split() if s.isdigit()]
        old="p cnf "+str(t[0])+" "+str(t[1])
        new="p cnf "+str(t[0])+" "+str(a)
        newnegative2=newnegative2
        ff=newnegative2.replace(old,new)+"\n"+newnegative
        
        self.writetofile(filethird+'tp/'+self.subjectname+'/tp_'+self.subjectname+".cnf",tt)
        self.writetofile(filethird+'fn/'+self.subjectname+'/fn_'+self.subjectname+".cnf",tf)
        self.writetofile(filethird+'fp/'+self.subjectname+'/fp_'+self.subjectname+".cnf",ft)
        self.writetofile(filethird+'tn/'+self.subjectname+'/tn_'+self.subjectname+".cnf",ff)
    def writetofile(self,name,text):
        f= open(name,"w")
        f.write(text)
    def run_models(self, am,filename):
        self.base_model_load(am,filename) # CALL BASE_MODEL METHOD
