# REQUIRED IMPORTS
import re
import time
import pydotplus
import numpy as np
from sklearn import svm
from sklearn import tree
import pickle
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.datasets import make_blobs
from sklearn.metrics import recall_score
from sklearn.externals.six import StringIO  
from sklearn.metrics import precision_score
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score,roc_auc_score)
from sklearn.model_selection import (train_test_split,GridSearchCV)
from sklearn.ensemble import (RandomForestClassifier,GradientBoostingClassifier,AdaBoostClassifier)
#########################################################################################################################
class tree_model:
    def __init__(self,subjectname, X_train,y_train,X_test,y_test):
        # GLOBAL VARIABLES
        self.subjectname=subjectname
        self.X_train=X_train
        self.X_test=X_test
        self.y_train=y_train
        self.y_test=y_test
        self.feature_names=[]
        self.poscon=[]
        self.neucon=[]
        self.negcon=[]
        self.totcon=[]
    def base_model_load(self,model,am):
        clf = model # GRIDSEARCH TO FIND BEST PARAMETERS
        clf.fit(self.X_train,self.y_train) # TRAIN MODEL
        y_pred = clf.predict(self.X_test)  # CALCULATE CONCRETE LABELS
        acc_score = accuracy_score(self.y_test, y_pred)  # CALCULATE ACCURACY SCORE
        precision=precision_score(self.y_test, y_pred) # PRINT PRECISION SCORE
        recall=recall_score(self.y_test, y_pred) # PRINT RECALL SCORE
        tn, fp, fn, tp = confusion_matrix(self.y_test, y_pred).ravel()  # CREATING A CONFUSION MATRIX
        print("{",str(am)+":"+str(100-am),"} , DT"," , ", tp," , " ,fn," , ", fp," , ", tn," , ", "%.4f" % ((tp+tn)/(tp+fn+fp+tn))," , " , \
        "%.4f" % precision," , ", "%.4f" % recall," , ","%.4f" % (2 * (precision * recall) / (precision + recall)),"\\\\") # PRINT CONFUSION MATRIX
    def run_models(self, am):
        tr = tree.DecisionTreeClassifier(random_state=0)  # CREATING MODEL
        self.base_model_load(tr,am) # CALL BASE_MODEL METHOD
        
        