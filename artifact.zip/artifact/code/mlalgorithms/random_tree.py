# REQUIRED IMPORTS
import re
import time
import numpy as np
from sklearn import svm
from sklearn import tree
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.datasets import make_blobs
from sklearn.metrics import recall_score
from sklearn.metrics import precision_score
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score,roc_auc_score)
from sklearn.model_selection import (train_test_split,GridSearchCV)
from sklearn.ensemble import (RandomForestClassifier,GradientBoostingClassifier,AdaBoostClassifier)
#########################################################################################################################
class random_model:
    def __init__(self, X_train,y_train,X_test,y_test):
        # GLOBAL VARIABLES
        self.X_train=X_train
        self.X_test=X_test
        self.y_train=y_train
        self.y_test=y_test
        self.feature_names=[]
#########################################################################################################################
    def base_model_load(self,model):
        clf = model # GRIDSEARCH TO FIND BEST PARAMETERS
        clf.fit(self.X_train,self.y_train) # TRAIN MODEL
        y_pred = clf.predict(self.X_test)  # CALCULATE CONCRETE LABELS
        acc_score = accuracy_score(self.y_test, y_pred)  # CALCULATE ACCURACY SCORE
        precision=precision_score(self.y_test, y_pred) # CALCULATE PRECISION SCORE
        recall=recall_score(self.y_test, y_pred) # CALCULATE RECALL SCORE
        tn, fp, fn, tp = confusion_matrix(self.y_test, y_pred).ravel()  # CREATING A CONFUSION MATRIX
        print(" , RFT"," , ", tp," , " ,fn," , ", fp," , ", tn," , ", "%.4f" % ((tp+tn)/(tp+fn+fp+tn))," , " , \
        "%.4f" % precision," , ", "%.4f" % recall," , ","%.4f" % (2 * (precision * recall) / (precision + recall)),"\\\\") # PRINT CONFUSION MATRIX
#########################################################################################################################
    def run_models(self):
        rf = RandomForestClassifier()  # CREATING MODEL
        self.base_model_load(rf) # CALL BASE_MODEL METHOD