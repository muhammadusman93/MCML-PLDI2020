# REQUIRED IMPORTS
import os
import re
import csv
import time
import math
import sys
import pydotplus
import subprocess
import warnings; warnings.simplefilter('ignore')
import numpy as np
from sklearn import svm
from sklearn import tree
from svm import svm_model
from mlp import mlp_model
from sklearn.svm import SVC
from trees import tree_model
import sklearn.model_selection
import matplotlib.pyplot as plt
from sklearn import preprocessing
from adaboost import adaboost_model
from gradient import gradient_model
from random_tree import random_model
from sklearn.datasets import make_blobs
from sklearn.metrics import recall_score
from sklearn.externals.six import StringIO  
from sklearn.metrics import precision_score
from sklearn.metrics import confusion_matrix
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.metrics import (accuracy_score,roc_auc_score)
from sklearn.model_selection import (train_test_split,GridSearchCV)
from sklearn.ensemble import (RandomForestClassifier,GradientBoostingClassifier,AdaBoostClassifier)
data_path=str(sys.argv[1])  # SPECIFY THE PATH WHERE YOUR ALLOY CSV FILES ARE LOCATED
#########################################################################################################################
def parse_file(pather): # PARSE FILE METHOD TO READ DATA
    inputfile = csv.reader(open(pather,'r')) # DEFINES THE INPUT FILE
    for row in inputfile: # TRAVERSES ALL ROWS OF DATA
       original.append(list(map(int, row[0:-1]))) # ORIGINAL STORES DATA FEATURES
       result.append(list(map(int, row[-1]))) # RESULT STORES DATA LABELS
datas=[]    # DATAS ARRAY STORE LIST OF FILES TO WORK ON
datastemp=[]
X_train=[]  # X_TRAIN WILL STORE TRAINING FEAUTRES. 
y_train=[]  # Y_TRAIN WILL STORE TRAINIGN LABELS
X_test=[]   # X_TEST WILL STORE TESTING FEATURES
y_test=[]   # Y_TEST WILL STORE TESTING LABELS
#########################################################################################################################
# THESE ARE FILES WHICH WE ARE WORKING ON.
propertyoption=str(sys.argv[1])
datas.append(data_path+".csv")
datastemp.append(propertyoption)

count=-1

# THIS RUNS THE MAIN METHOD
ratio=[0.25,0.50,0.75,0.90,0.99]
for i in datas: # ITERATE OVER ALL CSV FILES
    count=count+1
    print(i)  # PRINT WHICH FILE I AM WORKING ON 
    original=[] # RESETS THE FEATURE ARRAY
    result=[] # RESETS THE LABEL ARRAY
    parse_file(i) # CALLS PARSE_FILE METHOD
    finaloriginal=np.array(original) # CONVERTING FEATURE VECTOR TO NUMPY ARRAY
    finalresult=np.array(result) # CONVERTING LABEL VECTOR TO NUMPY ARRAY
    for j in range(len(ratio)): # ITERATE OVER ALL TRAIN TEST RATIONS
        print("Train:Test Ratio,ML Model,TP, FN, FP, TN, Accuracy, Precision, Recall, F1-Score")
        X_train, X_test, y_train, y_test = train_test_split(finaloriginal, finalresult, test_size=ratio[j], random_state=42) # TRAIN-TEST SPLIT FUNCTION
        q=tree_model(datastemp[count], X_train,  y_train,X_test, y_test) # CREATES THE MODEL 
        q.run_models( int(100-ratio[j]*100)); # CALL THE RUN_MODELS METHOD
        q = random_model(X_train, y_train, X_test, y_test) # CREATES THE MODEL 
        q.run_models(); # CALL THE RUN_MODELS METHOD
        q = gradient_model(X_train, y_train, X_test, y_test) # CREATES THE MODEL
        q.run_models(); # CALL THE RUN_MODELS METHOD
        q = adaboost_model(X_train, y_train, X_test, y_test) # CREATES THE MODEL
        q.run_models(); # CALL THE RUN_MODELS METHOD
        q = svm_model(X_train, y_train, X_test, y_test) # CREATES THE MODEL
        q.run_models(); # CALL THE RUN_MODELS METHOD
        q = mlp_model(X_train, y_train, X_test, y_test) # CREATES THE MODEL
        q.run_models(); # CALL THE RUN_MODELS METHOD
        print("\hline")
