import os
import signal
import sys
import subprocess

executable = 'modelcounter/projMC_linux'
timeout = 5000
files =[]

def recursiveopen(loc):
	for file in os.listdir(loc):
		if file == '..' or file == '.':
			continue
		if os.path.isdir(loc+file+"/"):
			recursiveopen(loc+file+"/")
		elif os.path.isfile(loc+file) and file.endswith(".cnf"):
			files.append(loc+file)
paths=str(sys.argv[1])
recursiveopen(paths)
for f in files:
	sys.stdout.flush()
	sys.stderr.flush()
	v = "-fpv=\""+ f[:-3]+"var\""
	l = [executable,f,v]
	sys.stdout.write(str(f)+",") #print test name
	sys.stdout.flush()
	sys.stderr.flush()
	pro = subprocess.Popen("exec "+" ".join(l), shell=True)
	try:		
		pro.wait(timeout)
		sys.stdout.flush()
		sys.stderr.flush()
	except subprocess.TimeoutExpired:
		pro.kill()
		print("5000,unknown")
		sys.stdout.flush()
		sys.stderr.flush()
