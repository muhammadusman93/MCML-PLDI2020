import os
import signal
import sys
import subprocess

executable = '/home/musman/Desktop/usman_projmc/projMC_linux'
timeout = 1000
files =[]

def recursiveopen(loc):
	for file in os.listdir(loc):
		if file == '..' or file == '.':
			continue
		if os.path.isdir(loc+file+"/"):
			recursiveopen(loc+file+"/")
		elif os.path.isfile(loc+file) and file.endswith(".cnf"):
			files.append(loc+file)

recursiveopen(sys.argv[1])

for f in files:
	sys.stdout.flush()
	sys.stderr.flush()
	v = "-fpv=\""+ f[:-3]+"var\""
	l = ["python3 converter.py",f[:-4]]
	#sys.stdout.write(str(f)+",") #print test name
	sys.stdout.flush()
	sys.stderr.flush()
	pro = subprocess.Popen(" ".join(l), shell=True)
	try:		
		pro.wait(timeout)
		sys.stdout.flush()
		sys.stderr.flush()
	except subprocess.TimeoutExpired:
		pro.kill()
		print("unknown,1000")
		sys.stdout.flush()
		sys.stderr.flush()
