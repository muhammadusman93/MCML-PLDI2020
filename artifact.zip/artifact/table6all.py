import sys
import os
import re


def extraction(var):
    varreturn = 0
    with open("output/table6-"+var+".txt") as f:
        for line in f:
            pass
        last_line = line
        if("s " in last_line):
            varreturn = int(re.findall(r'\d+', str(last_line))[0])
            return varreturn
        return -1


propertyoption2 = ["antisymmetric", "bijective", "connex", "equivalence", "function", "functional", "injective", "irreflexive",
                   "nonstrictorder", "partialorder", "preorder", "reflexive", "strictorder", "surjective", "totalorder", "transitive"]
for propertyoption in propertyoption2:
    os.system("python3 code/ground-tree/mcml.py datasets/csv/Sym-Brk-On/ datasets/cnf/large/symoff/ output/groundoff_treeon/ "+propertyoption)

    tp = 0
    tn = 0
    fn = 0
    fp = 0
    os.system(
        "python3 converterrunner.py output/groundoff_treeon/tp/"+propertyoption+"/")
    os.system("python3 runmodelcounter.py output/groundoff_treeon/tp/" +
              propertyoption+"/ > output/table6-"+propertyoption+"-tp.txt")
    tp = extraction(propertyoption+"-tp")

    os.system(
        "python3 converterrunner.py output/groundoff_treeon/tn/"+propertyoption+"/")
    os.system("python3 runmodelcounter.py output/groundoff_treeon/tn/" +
              propertyoption+"/ > output/table6-"+propertyoption+"-tn.txt")
    tn = extraction(propertyoption+"-tn")

    os.system(
        "python3 converterrunner.py output/groundoff_treeon/fp/"+propertyoption+"/")
    os.system("python3 runmodelcounter.py output/groundoff_treeon/fp/" +
              propertyoption+"/ > output/table6-"+propertyoption+"-fp.txt")
    fp = extraction(propertyoption+"-fp")

    os.system(
        "python3 converterrunner.py output/groundoff_treeon/fn/"+propertyoption+"/")
    os.system("python3 runmodelcounter.py output/groundoff_treeon/fn/" +
              propertyoption+"/ > output/table6-"+propertyoption+"-fn.txt")
    fn = extraction(propertyoption+"-fn")
    print("*********************************************************************************************************************")	
    print("Property", "TP", "FN", "FP", "TN",
          "Accuracy", "Precision", "Recall", "F1-Score")
    if(tn == -1 or tp == -1 or fp == -1 or fn == -1):
        print(propertyoption,"Timeout")
    else:
        accuracy = (tp+tn)/(tp+tn+fp+fn)
        precision = (tp)/(tp+fp)
        recall = (tp)/(tp+fn)
        f1score = (2*precision*recall)/(recall+precision)
        print(propertyoption, tp, fn, fp, tn, round(accuracy, 4),
              round(precision, 4), round(recall, 4), round(f1score, 4))
    print("*********************************************************************************************************************")
