import sys
import os
import warnings
import re
warnings.simplefilter(action='ignore', category=FutureWarning)


def extraction(var):
    varreturn = 0
    with open("output/table8-"+var+".txt") as f:
        for line in f:
            pass
        last_line = line
        if("s " in last_line):
            varreturn = int(re.findall(r'\d+', str(last_line))[0])
            return varreturn
        return -1


propertyoption2 = ["antisymmetric", "bijective", "connex", "equivalence", "function", "functional", "injective", "irreflexive",
                   "nonstrictorder", "partialorder", "preorder", "reflexive", "strictorder", "surjective", "totalorder", "transitive"]
for propertyoption in propertyoption2:
    os.system(
        "python3 code/tree-tree/mcml.py datasets/csv/Sym-Brk-On/ output/treeon_treeon/ "+propertyoption)

    tp = 0
    tn = 0
    fn = 0
    fp = 0
    os.system("python3 converterrunner.py output/treeon_treeon/tp/" +
              propertyoption+"/")
    os.system("python3 runmodelcounter.py output/treeon_treeon/tp/" +
              propertyoption+"/ > output/table8-"+propertyoption+"-tp.txt")
    tp = extraction(propertyoption+"-tp")

    os.system("python3 converterrunner.py output/treeon_treeon/tn/" +
              propertyoption+"/")
    os.system("python3 runmodelcounter.py output/treeon_treeon/tn/" +
              propertyoption+"/ > output/table8-"+propertyoption+"-tn.txt")
    tn = extraction(propertyoption+"-tn")

    os.system("python3 converterrunner.py output/treeon_treeon/fp/" +
              propertyoption+"/")
    os.system("python3 runmodelcounter.py output/treeon_treeon/fp/" +
              propertyoption+"/ > output/table8-"+propertyoption+"-fp.txt")
    fp = extraction(propertyoption+"-fp")

    os.system("python3 converterrunner.py output/treeon_treeon/fn/" +
              propertyoption+"/")
    os.system("python3 runmodelcounter.py output/treeon_treeon/fn/" +
              propertyoption+"/ > output/table8-"+propertyoption+"-fn.txt")
    fn = extraction(propertyoption+"-fn")
    print("*********************************************************************************************************************")	
    print("Property", "TT", "TF", "FT", "FF", "Diff")
    if(tn == -1 or tp == -1 or fp == -1 or fn == -1):
        print(propertyoption,"Timeout")
    else:
        accuracy = (tp+tn)/(tp+tn+fp+fn)
        precision = (tp)/(tp+fp)
        recall = (tp)/(tp+fn)
        f1score = (2*precision*recall)/(recall+precision)
        print(propertyoption, tp, fn, fp, tn, round(100*(1-accuracy), 2))

    print("*********************************************************************************************************************")
