import sys
import os
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"antisymmetric")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"bijective")
os.system("python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"connex")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"equivalence")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"function")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"functional")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"injective")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"irreflexive")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"nonstrictorder")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"partialorder")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"preorder")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"reflexive")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"strictorder")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"surjective")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"totalorder")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-Off/"+"transitive")
