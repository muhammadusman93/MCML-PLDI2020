import sys
import os
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"antisymmetric")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"bijective")
os.system("python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"connex")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"equivalence")
os.system("python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"function")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"functional")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"injective")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"irreflexive")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"nonstrictorder")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"partialorder")
os.system("python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"preorder")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"reflexive")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"strictorder")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"surjective")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"totalorder")
os.system(
    "python3 code/mlalgorithms/learning.py datasets/csv/Sym-Brk-On/"+"transitive")
