import sys
import os
import re
propertyoption=str(sys.argv[1])
with open('output/table3-partialorder.txt') as f:
    for line in f:
        pass
    last_line = line
var=int(re.findall(r'\d+',str(last_line))[0])
print(var)
